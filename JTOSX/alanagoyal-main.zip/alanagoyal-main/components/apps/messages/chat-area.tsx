import { Conversation, Reaction } from "@/types/messages";
import { useEffect, useRef, useState } from "react";
import { ChatHeader } from "./chat-header";
import { MessageInput } from "./message-input";
import { MessageList } from "./message-list";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { useWindowFocus } from "@/lib/window-focus-context";
import { extractMessageContent } from "@/lib/messages/content";

interface ChatAreaProps {
  isNewChat: boolean;
  activeConversation?: Conversation;
  recipientInput: string;
  setRecipientInput: (value: string) => void;
  isMobileView?: boolean;
  onBack?: () => void;
  onSendMessage: (message: string, conversationId?: string) => void;
  onReaction?: (messageId: string, reaction: Reaction) => void;
  typingStatus: { conversationId: string; recipient: string } | null;
  conversationId: string | null;
  onUpdateConversationRecipients?: (
    conversationId: string,
    recipients: string[]
  ) => void;
  onCreateConversation?: (recipientNames: string[]) => void;
  onUpdateConversationName?: (name: string) => void;
  onHideAlertsChange?: (hide: boolean) => void;
  messageDraft?: string;
  onMessageDraftChange?: (conversationId: string, message: string) => void;
  unreadCount?: number;
  isDesktop?: boolean;
  focusModeActive?: boolean;
  isWindowFocused?: boolean;
  justSentMessageId?: string | null;
}

type NavigatorWithVirtualKeyboard = Navigator & {
  virtualKeyboard?: {
    overlaysContent: boolean;
  };
};

export function ChatArea({
  isNewChat,
  activeConversation,
  recipientInput,
  setRecipientInput,
  isMobileView,
  onBack,
  onSendMessage,
  onReaction,
  typingStatus,
  conversationId,
  onUpdateConversationRecipients,
  onCreateConversation,
  onUpdateConversationName,
  onHideAlertsChange,
  messageDraft = "",
  onMessageDraftChange,
  unreadCount = 0,
  isDesktop = false,
  focusModeActive = false,
  isWindowFocused = true,
  justSentMessageId,
}: ChatAreaProps) {
  const [showCompactNewChat, setShowCompactNewChat] = useState(false);

  useEffect(() => {
    if (isNewChat) {
      setShowCompactNewChat(false);
    }
  }, [isNewChat]);

  const showRecipientInput = isNewChat && !activeConversation;
  const messageInputRef = useRef<{ focus: () => void }>(null);

  useEffect(() => {
    const nav = navigator as NavigatorWithVirtualKeyboard;
    if (nav.virtualKeyboard) {
      nav.virtualKeyboard.overlaysContent = true;
    }
  }, []);

  // Get window focus state from context (available when in desktop shell)
  const windowFocus = useWindowFocus();

  // Track previous focus state to detect focus transitions
  const wasFocusedRef = useRef(windowFocus?.isFocused ?? true);

  // Focus the message input when the window gains focus and there's an active conversation
  useEffect(() => {
    const isFocused = windowFocus?.isFocused ?? true;
    const wasFocused = wasFocusedRef.current;

    // Detect transition from unfocused to focused
    if (isFocused && !wasFocused && !isMobileView) {
      // Focus the message input if there's an active conversation
      if (activeConversation && messageInputRef.current) {
        messageInputRef.current.focus();
      }
    }

    wasFocusedRef.current = isFocused;
  }, [windowFocus?.isFocused, activeConversation, isMobileView]);

  const conversationRecipients = activeConversation?.recipients || [];

  // Create a key that changes when recipients change
  const messageInputKey = conversationRecipients.map((r) => r.id).join(",");

  const handleMessageChange = (msg: string) => {
    if (isNewChat) {
      onMessageDraftChange?.("new", msg);
    } else if (conversationId) {
      onMessageDraftChange?.(conversationId, msg);
    }
  };

  const handleSend = (): boolean => {
    if (!extractMessageContent(messageDraft).trim()) return false;

    if (activeConversation) {
      onSendMessage(messageDraft, activeConversation.id);
      return true;
    } else if (isNewChat && recipientInput.trim()) {
      const recipientList = recipientInput
        .split(",")
        .map((r) => r.trim())
        .filter((r) => r.length > 0);
      if (recipientList.length > 0) {
        onSendMessage(messageDraft);
        return true;
      }
    }
    return false;
  };

  return (
    <div className="h-full relative flex flex-col overflow-x-hidden">
      <div className="absolute top-0 left-0 right-0 z-50">
        <ChatHeader
          isNewChat={showRecipientInput}
          recipientInput={recipientInput}
          setRecipientInput={setRecipientInput}
          onBack={onBack}
          isMobileView={isMobileView}
          activeConversation={activeConversation}
          onUpdateRecipients={
            onUpdateConversationRecipients && conversationId
              ? (recipients) =>
                  onUpdateConversationRecipients(conversationId, recipients)
              : undefined
          }
          onCreateConversation={onCreateConversation}
          onUpdateConversationName={onUpdateConversationName}
          onHideAlertsChange={onHideAlertsChange}
          unreadCount={unreadCount}
          showCompactNewChat={showCompactNewChat}
          setShowCompactNewChat={setShowCompactNewChat}
          isDesktop={isDesktop}
        />
      </div>
      <ScrollArea
        className="h-full flex flex-col"
        isMobile={isMobileView}
        withVerticalMargins
        mobileHeaderHeight={isMobileView}
        bottomMargin="calc(var(--dynamic-height, 64px))"
      >
        <div
          className={cn(
            "min-h-full flex flex-col",
            isMobileView ? "pt-24" : "pt-16",
            "pb-[var(--dynamic-height,64px)]"
          )}
        >
          <div className="flex-1 flex flex-col relative">
            <div className="relative h-full flex">
              <div className="w-3 bg-background" />
              <MessageList
                messages={activeConversation?.messages || []}
                conversation={activeConversation}
                typingStatus={
                  typingStatus?.conversationId === conversationId
                    ? typingStatus
                    : null
                }
                onReaction={(messageId, reaction) => {
                  onReaction?.(messageId, reaction);
                }}
                conversationId={conversationId}
                messageInputRef={messageInputRef}
                isMobileView={isMobileView}
                focusModeActive={focusModeActive}
                isWindowFocused={isWindowFocused}
                justSentMessageId={justSentMessageId}
              />
              <div className="w-3 bg-background" />
            </div>
            <div className="bg-background flex-1" />
          </div>
        </div>
      </ScrollArea>
      <div className="absolute bottom-0 left-0 right-0 z-50 mb-[env(keyboard-inset-height,0px)]">
        <MessageInput
          key={messageInputKey}
          ref={messageInputRef}
          message={messageDraft}
          setMessage={handleMessageChange}
          handleSend={handleSend}
          disabled={isNewChat && !recipientInput}
          recipients={conversationRecipients}
          isMobileView={isMobileView}
          conversationId={conversationId || undefined}
          isNewChat={isNewChat}
        />
      </div>
    </div>
  );
}
